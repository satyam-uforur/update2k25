"use client"

import { useEffect, useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Marquee3D } from "@/components/marquee3d"
import { DockBar } from "@/components/dock-bar"
import { MagicCard } from "@/components/magicui/magic-card"
import { CountdownTimer } from "@/components/countdown-timer"
import { HyperText } from "@/components/magicui/hyper-text"
import { Shield, Cpu, Network, Fingerprint, Zap, Lock, Eye } from "lucide-react"

export default function HomePage() {
  const [scrollY, setScrollY] = useState(0)
  const [mousePosition, setMousePosition] = useState({ x: 0, y: 0 })

  useEffect(() => {
    const handleScroll = () => setScrollY(window.scrollY)
    const handleMouseMove = (e: MouseEvent) => {
      setMousePosition({ x: e.clientX, y: e.clientY })
    }

    window.addEventListener("scroll", handleScroll)
    window.addEventListener("mousemove", handleMouseMove)

    return () => {
      window.removeEventListener("scroll", handleScroll)
      window.removeEventListener("mousemove", handleMouseMove)
    }
  }, [])

  return (
    <div className="min-h-screen bg-black relative pb-16 overflow-x-hidden">
      <div className="fixed inset-0 pointer-events-none overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-br from-black via-gray-900/10 to-black" />
        <div className="absolute inset-0 bg-gradient-to-t from-black via-transparent to-black/50" />
        <div
          className="absolute w-96 h-96 bg-green-500/8 rounded-full blur-3xl transition-all duration-500 ease-out"
          style={{
            left: mousePosition.x - 192,
            top: mousePosition.y - 192,
          }}
        />
        <div className="absolute top-1/4 right-1/4 w-96 h-96 bg-green-400/6 rounded-full blur-3xl animate-pulse delay-1000" />
        <div className="absolute bottom-1/4 left-1/3 w-80 h-80 bg-green-600/4 rounded-full blur-3xl animate-pulse delay-2000" />
        <div className="absolute top-3/4 left-1/4 w-72 h-72 bg-green-500/5 rounded-full blur-3xl animate-pulse delay-3000" />
      </div>

      <div className="fixed inset-0 w-full h-screen pointer-events-none z-0">
        <div className="absolute inset-0 opacity-15">
          <Marquee3D />
        </div>
        <div className="absolute inset-0 bg-gradient-to-b from-transparent via-black/20 to-black/60" />
        <div className="absolute inset-0 bg-gradient-to-r from-black/30 via-transparent to-black/30" />
      </div>

      <section className="relative h-screen overflow-hidden flex flex-col items-center justify-center">
        <div className="absolute inset-0 bg-black/20" />

        <div className="absolute inset-0 opacity-60">
          <div className="spark absolute top-20 left-20 w-2 h-2 bg-green-400 rounded-full animate-ping" />
          <div className="spark absolute top-32 right-32 w-1 h-1 bg-green-500 rounded-full animate-ping delay-300" />
          <div className="spark absolute bottom-32 left-1/3 w-1.5 h-1.5 bg-green-400 rounded-full animate-ping delay-700" />
          <div className="spark absolute bottom-20 right-20 w-2 h-2 bg-green-500 rounded-full animate-ping delay-1000" />
          <div className="spark absolute top-1/2 left-10 w-1 h-1 bg-green-400 rounded-full animate-ping delay-500" />
          <div className="spark absolute top-1/3 right-10 w-1.5 h-1.5 bg-green-500 rounded-full animate-ping delay-1200" />
          <div className="spark absolute top-40 left-1/2 w-1 h-1 bg-green-400 rounded-full animate-ping delay-800" />
          <div className="spark absolute bottom-40 right-1/3 w-1.5 h-1.5 bg-green-500 rounded-full animate-ping delay-1500" />
          <div className="spark absolute top-60 right-1/4 w-2 h-2 bg-green-400 rounded-full animate-ping delay-200" />
          <div className="spark absolute bottom-60 left-1/4 w-1 h-1 bg-green-500 rounded-full animate-ping delay-1800" />
        </div>

        <div className="relative z-10 text-center px-4 max-w-4xl mx-auto">
          <div className="float-animation mb-8">
            <HyperText
              className="text-6xl md:text-8xl font-bold bg-gradient-to-r from-green-400 via-white to-green-400 bg-clip-text text-transparent mb-6 font-mono tracking-wider relative"
              style={{ textShadow: "0 0 30px #00ff41, 0 0 60px #00ff41" }}
              delay={500}
            >
              UPDATES
            </HyperText>
            <HyperText
              className="text-4xl md:text-6xl font-bold bg-gradient-to-r from-white via-green-400 to-white bg-clip-text text-transparent mb-6 font-mono tracking-wider relative"
              style={{ textShadow: "0 0 30px #00ff41, 0 0 60px #00ff41" }}
              delay={1500}
            >
              2K25
            </HyperText>
          </div>

          <CountdownTimer />
        </div>
      </section>

      <section className="py-20 px-4 relative">
        <div className="absolute inset-0 bg-gradient-to-b from-black/50 via-transparent to-black/50" />
        <div className="max-w-6xl mx-auto relative z-10">
          <HyperText
            className="text-3xl md:text-4xl font-bold text-center text-green-400 mb-8"
            animateOnScroll={true}
            delay={200}
          >
            Cybersecurity will revolutionize digital protection forever.
          </HyperText>
        </div>
      </section>

      <section className="py-20 px-4 relative">
        <div className="absolute inset-0 bg-gradient-to-b from-black/30 via-gray-900/5 to-black/30" />
        <div className="max-w-6xl mx-auto relative z-10">
          <div className="text-center mb-16">
            <Badge
              variant="secondary"
              className="mb-4 text-lg px-4 py-2 bg-green-500/20 text-green-400 border-green-400 font-mono"
            >
              Security Suite
            </Badge>
            <HyperText
              className="text-4xl md:text-5xl font-bold text-green-400 mb-6 font-mono"
              style={{ textShadow: "0 0 15px #00ff4150" }}
              animateOnScroll={true}
              delay={300}
            >
              Defense Matrix
            </HyperText>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-12">
            <MagicCard className="h-64">
              <div className="flex flex-col items-center justify-center h-full text-center p-6">
                <Shield className="w-12 h-12 text-green-400 mb-4" />
                <HyperText
                  className="text-xl font-bold text-green-400 mb-2 font-mono"
                  animateOnScroll={true}
                  delay={100}
                >
                  Quantum Shield
                </HyperText>
                <p className="text-green-300/70 text-sm font-mono">Advanced quantum encryption</p>
              </div>
            </MagicCard>

            <MagicCard className="h-64">
              <div className="flex flex-col items-center justify-center h-full text-center p-6">
                <Network className="w-12 h-12 text-green-400 mb-4" />
                <HyperText
                  className="text-xl font-bold text-green-400 mb-2 font-mono"
                  animateOnScroll={true}
                  delay={200}
                >
                  Neural Firewall
                </HyperText>
                <p className="text-green-300/70 text-sm font-mono">AI-powered threat detection</p>
              </div>
            </MagicCard>

            <MagicCard className="h-64">
              <div className="flex flex-col items-center justify-center h-full text-center p-6">
                <Fingerprint className="w-12 h-12 text-green-400 mb-4" />
                <HyperText
                  className="text-xl font-bold text-green-400 mb-2 font-mono"
                  animateOnScroll={true}
                  delay={300}
                >
                  Biometric Lock
                </HyperText>
                <p className="text-green-300/70 text-sm font-mono">Multi-factor authentication</p>
              </div>
            </MagicCard>

            <MagicCard className="h-64">
              <div className="flex flex-col items-center justify-center h-full text-center p-6">
                <Cpu className="w-12 h-12 text-green-400 mb-4" />
                <HyperText
                  className="text-xl font-bold text-green-400 mb-2 font-mono"
                  animateOnScroll={true}
                  delay={400}
                >
                  Crypto Engine
                </HyperText>
                <p className="text-green-300/70 text-sm font-mono">High-performance encryption</p>
              </div>
            </MagicCard>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <MagicCard className="h-64">
              <div className="flex flex-col items-center justify-center h-full text-center p-6">
                <Zap className="w-12 h-12 text-green-400 mb-4" />
                <HyperText
                  className="text-xl font-bold text-green-400 mb-2 font-mono"
                  animateOnScroll={true}
                  delay={500}
                >
                  Lightning Response
                </HyperText>
                <p className="text-green-300/70 text-sm font-mono">Instant threat neutralization</p>
              </div>
            </MagicCard>

            <MagicCard className="h-64">
              <div className="flex flex-col items-center justify-center h-full text-center p-6">
                <Lock className="w-12 h-12 text-green-400 mb-4" />
                <HyperText
                  className="text-xl font-bold text-green-400 mb-2 font-mono"
                  animateOnScroll={true}
                  delay={600}
                >
                  Secure Vault
                </HyperText>
                <p className="text-green-300/70 text-sm font-mono">Impenetrable data storage</p>
              </div>
            </MagicCard>

            <MagicCard className="h-64">
              <div className="flex flex-col items-center justify-center h-full text-center p-6">
                <Eye className="w-12 h-12 text-green-400 mb-4" />
                <HyperText
                  className="text-xl font-bold text-green-400 mb-2 font-mono"
                  animateOnScroll={true}
                  delay={700}
                >
                  Surveillance Net
                </HyperText>
                <p className="text-green-300/70 text-sm font-mono">24/7 monitoring system</p>
              </div>
            </MagicCard>
          </div>
        </div>
      </section>

      <section className="py-32 px-4 relative overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-b from-black/50 via-gray-900/10 to-black/50" />
        <div className="relative z-10">
          <div className="text-center mb-16">
            <Badge
              variant="secondary"
              className="mb-4 text-lg px-4 py-2 bg-green-500/20 text-green-400 border-green-400 font-mono"
            >
              Security Matrix
            </Badge>
            <h2
              className="text-4xl md:text-5xl font-bold text-green-400 mb-6 font-mono"
              style={{ textShadow: "0 0 15px #00ff4150" }}
            >
              Threat Intelligence
            </h2>
          </div>
          <Marquee3D />
        </div>
      </section>

      <section className="py-20 px-4 relative">
        <div className="absolute inset-0 bg-gradient-to-b from-black/30 via-transparent to-black/30" />
        <div className="max-w-6xl mx-auto relative z-10">
          <div className="text-center mb-16" style={{ transform: `translateY(${(scrollY - 800) * 0.1}px)` }}>
            <Badge
              variant="secondary"
              className="mb-4 text-lg px-4 py-2 bg-green-500/20 text-green-400 border-green-400 font-mono"
            >
              Defense Systems
            </Badge>
            <HyperText
              className="text-4xl md:text-5xl font-bold text-green-400 mb-6 font-mono"
              style={{ textShadow: "0 0 15px #00ff4150" }}
              animateOnScroll={true}
              delay={200}
            >
              Security Protocols
            </HyperText>
            <HyperText
              className="text-xl text-green-300/70 max-w-2xl mx-auto leading-relaxed font-mono"
              animateOnScroll={true}
              delay={500}
            >
              Military-grade protection systems designed for the cyber battlefield
            </HyperText>
          </div>

          <div className="grid md:grid-cols-3 gap-8">
            {[
              {
                title: "Quantum Encryption",
                description:
                  "Unbreakable quantum-resistant algorithms protecting against future threats and advanced persistent attacks.",
                icon: "🔐",
              },
              {
                title: "Neural Firewall",
                description:
                  "AI-powered threat detection with machine learning capabilities for real-time intrusion prevention.",
                icon: "🛡️",
              },
              {
                title: "Biometric Auth",
                description:
                  "Multi-factor biometric authentication with fingerprint, retinal, and behavioral pattern recognition.",
                icon: "👁️",
              },
            ].map((feature, index) => (
              <Card
                key={index}
                className="bg-gray-900/50 border-green-400/30 hover:border-green-400 transition-all duration-300 group shadow-[0_0_15px_rgba(0,255,65,0.1)]"
                style={{
                  transform: `translateY(${(scrollY - 1000) * (0.05 + index * 0.02)}px)`,
                  opacity: scrollY > 600 ? 1 : 0.7,
                }}
              >
                <CardContent className="p-8 text-center">
                  <div className="text-4xl mb-4 group-hover:scale-110 transition-transform duration-300">
                    {feature.icon}
                  </div>
                  <HyperText
                    className="text-2xl font-bold text-green-400 mb-4 font-mono"
                    animateOnScroll={true}
                    delay={index * 200}
                  >
                    {feature.title}
                  </HyperText>
                  <p className="text-green-300/70 leading-relaxed font-mono text-sm">{feature.description}</p>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      <section className="py-20 px-4 bg-gray-900/20 relative">
        <div className="absolute inset-0 bg-gradient-to-b from-black/20 via-transparent to-black/20" />
        <div className="max-w-4xl mx-auto text-center relative z-10">
          <div style={{ transform: `translateY(${(scrollY - 1400) * 0.1}px)` }}>
            <div className="grid md:grid-cols-3 gap-8 text-center">
              {[
                { number: "99.99%", label: "Threat Detection Rate" },
                { number: "0.001s", label: "Response Time" },
                { number: "256-bit", label: "Encryption Standard" },
              ].map((stat, index) => (
                <div key={index} className="group">
                  <div
                    className="text-5xl md:text-6xl font-bold text-green-400 mb-2 font-mono"
                    style={{ textShadow: "0 0 15px #00ff4150" }}
                  >
                    {stat.number}
                  </div>
                  <div className="text-lg text-green-300/70 font-mono">{stat.label}</div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>

      <section className="py-20 px-4 relative">
        <div className="absolute inset-0 bg-gradient-to-b from-black/30 via-transparent to-black/30" />
        <div className="max-w-4xl mx-auto text-center relative z-10">
          <div style={{ transform: `translateY(${(scrollY - 1800) * 0.1}px)` }}>
            <HyperText
              className="text-4xl md:text-5xl font-bold text-green-400 mb-6 font-mono"
              style={{ textShadow: "0 0 15px #00ff4150" }}
              animateOnScroll={true}
              delay={200}
            >
              Initialize Protocol?
            </HyperText>
            <HyperText
              className="text-xl text-green-300/70 mb-8 leading-relaxed font-mono"
              animateOnScroll={true}
              delay={500}
            >
              Join the secure network and experience next-generation cybersecurity
            </HyperText>
            <Button
              size="lg"
              className="bg-green-500 hover:bg-green-400 text-black px-12 py-4 text-xl font-mono shadow-[0_0_20px_#00ff4150]"
            >
              Access Granted
            </Button>
          </div>
        </div>
      </section>

      <footer className="py-12 px-4 border-t border-green-400/30 relative">
        <div className="absolute inset-0 bg-gradient-to-t from-black/50 to-transparent" />
        <div className="max-w-6xl mx-auto text-center relative z-10">
          <p className="text-green-300/70 font-mono">© 2025 Updates 2K25. Secured by quantum encryption protocols.</p>
        </div>
      </footer>

      <DockBar />
    </div>
  )
}
